package com.aryaman.covid.ui.starships.view;

import com.aryaman.covid.data.models.Starship;

import java.util.List;

public interface IStarshipsView {
    void onStarshipsLoadedSuccess(List<Starship> starships);
    void onStarshipsLoadedError();
}
