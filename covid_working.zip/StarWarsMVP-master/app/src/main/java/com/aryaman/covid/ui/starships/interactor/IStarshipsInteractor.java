package com.aryaman.covid.ui.starships.interactor;

import com.aryaman.covid.data.models.Starship;

import java.util.List;

public interface IStarshipsInteractor {
    void onNetworkSuccess(List<Starship> starships);
    void onNetworkFailure();
}
