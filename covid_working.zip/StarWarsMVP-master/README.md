# <img src="app/src/main/res/mipmap-xxxhdpi/ic_launcher.png" width="42"> StarWarsMVP

Very simple Android MVP project using [*Retrofit*](http://square.github.io/retrofit/) to retrieve data from [*The Star Wars API*](https://swapi.co/), and showing how to use BottomNavigationView.

<img src="art/device-2017-07-02-184912.png" width="425">)
