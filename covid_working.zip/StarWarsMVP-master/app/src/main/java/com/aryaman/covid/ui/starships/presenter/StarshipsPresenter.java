package com.aryaman.covid.ui.starships.presenter;

import com.aryaman.covid.data.models.Starship;
import com.aryaman.covid.ui.starships.interactor.IStarshipsInteractor;
import com.aryaman.covid.ui.starships.interactor.StarshipsInteractor;
import com.aryaman.covid.ui.starships.view.IStarshipsView;

import java.util.List;

public class StarshipsPresenter implements IStarshipsPresenter, IStarshipsInteractor {

    private IStarshipsView view;
    private StarshipsInteractor interactor;

    public StarshipsPresenter(IStarshipsView view) {
        this.view = view;
        this.interactor = new StarshipsInteractor(this);
    }

    @Override
    public void loadStarships() {
        interactor.getStarshipsFromServer();
    }

    @Override
    public void onNetworkSuccess(List<Starship> starships) {
        view.onStarshipsLoadedSuccess(starships);
    }

    @Override
    public void onNetworkFailure() {
        view.onStarshipsLoadedError();
    }
}
