package com.aryaman.covid.ui;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

import com.aryaman.covid.R;
import com.aryaman.covid.ui.characters.view.CharactersFragment;
import com.aryaman.covid.ui.planets.view.PlanetsFragment;
import com.aryaman.covid.ui.starships.view.StarshipsFragment;

import butterknife.BindView;
import butterknife.ButterKnife;

public class BottomNavigationActivity extends AppCompatActivity {

    @BindView(R.id.bottom_navigation)
    BottomNavigationView bottomNavigationView;

    PlanetsFragment planetsFragment;
    CharactersFragment charactersFragment;
    StarshipsFragment starshipsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bottom_navigation);

        ButterKnife.bind(this);

        planetsFragment = new PlanetsFragment();
        charactersFragment = new CharactersFragment();
        starshipsFragment = new StarshipsFragment();

        showFragment(planetsFragment);

        bottomNavigationView.setOnNavigationItemSelectedListener(
                new BottomNavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                        switch (item.getItemId()) {
                            case R.id.action_planets:
                                showFragment(planetsFragment);
                                break;
                            case R.id.action_schedules:
                                showFragment(charactersFragment);
                                break;
                            case R.id.action_music:
                                showFragment(starshipsFragment);
                                break;
                        }
                        return false;
                    }
                });
    }

    public void showFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.navigation_placeholder, fragment);
        fragmentTransaction.commit();
    }
}
