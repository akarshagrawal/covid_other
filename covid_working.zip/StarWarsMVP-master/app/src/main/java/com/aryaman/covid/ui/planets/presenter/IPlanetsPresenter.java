package com.aryaman.covid.ui.planets.presenter;

public interface IPlanetsPresenter {
    public void loadPlanets();
}
