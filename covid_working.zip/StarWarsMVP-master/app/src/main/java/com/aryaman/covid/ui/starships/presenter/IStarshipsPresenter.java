package com.aryaman.covid.ui.starships.presenter;

public interface IStarshipsPresenter {
    public void loadStarships();
}
