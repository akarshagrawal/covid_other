package com.aryaman.covid.ui.characters.Presenter;

public interface ICharactersPresenter {
    public void loadCharacters();
}
